# Example Python Code to Insert a Document 


from pymongo import MongoClient 
from pymongo.errors import PyMongoError
from bson.objectid import ObjectId 

class AnimalShelter(object): 
    """ CRUD operations for Animal collection in MongoDB """ 

    def __init__(self): 
        # Initializing the MongoClient. This helps to access the MongoDB 
        # databases and collections. This is hard-wired to use the aac 
        # database, the animals collection, and the aac user. 
        # 
        # You must edit the password below for your environment. 
        # 
        # Connection Variables 
        # 
        USER = 'aacuser' 
        PASS = 'DRH021981' 
        HOST = 'localhost' 
        PORT = 27017 
        DB = 'aac' 
        COL = 'animals' 
        # 
        # Initialize Connection 
        # 
        self.client = MongoClient(
            'mongodb://%s:%s@%s:%d/?authSource=admin' % (USER, PASS, HOST, PORT)
        ) 
        self.database = self.client['%s' % (DB)] 
        self.collection = self.database['%s' % (COL)] 

    # Create a method to return the next available record number for use in the create method
            
    # Complete this create method to implement the C in CRUD. 
    def create(self, data):
        if data is not None and isinstance(data, dict) and len(data) > 0:
            try:
                self.collection.insert_one(data)
                return True
            except PyMongoError as e:
                print("Create error:", e)
                return False
        else: 
            raise Exception("Nothing to save, because data parameter is empty") 

    # Create method to implement the R in CRUD. 
    def read(self, query, projection=None):
        if query is not None and isinstance(query, dict):
            try:
                if projection is not None and isinstance(projection, dict):
                    cursor = self.collection.find(query, projection)
                else:
                    cursor = self.collection.find(query)
                return list(cursor)
            except PyMongoError as e:
                print("Read error:", e)
                return []
        else:
            return []
        
    # Create method to implement the U in CRUD.
    def update(self, query, new_values):
        if query is not None and isinstance(query, dict) and new_values is not None and isinstance(new_values, dict) and len(new_values) > 0:
            try:
                result = self.collection.update_many(query, {"$set": new_values})
                return result.modified_count
            except PyMongoError as e:
                print("Update error:", e)
                return 0
        else:
            return 0

    # Create method to implement the D in CRUD.
    def delete(self, query):
        if query is not None and isinstance(query, dict):
            try:
                result = self.collection.delete_many(query)
                return result.deleted_count
            except PyMongoError as e:
                print("Delete error:", e)
                return 0
        else:
            return 0